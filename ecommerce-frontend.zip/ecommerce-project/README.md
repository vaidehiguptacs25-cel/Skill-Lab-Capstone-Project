# E-Commerce Platform - Frontend (Part 1)
Run: open `frontend/` in VS Code and use **Live Server** on `frontend/index.html`. No install needed.
Data is mock (localStorage). All data access is in `js/api.js` (`USE_MOCK`, `BASE_URL`) so the backend swap only touches that file.

Test accounts: Admin `admin@shop.com` / `Admin1234` - Customer `customer@shop.com` / `Cust1234`
Reset data: clear localStorage in DevTools.
