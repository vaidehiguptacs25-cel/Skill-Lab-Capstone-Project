/* ============================================================================
   mockData.js
   Purpose: fake starting data (categories, products, users, orders) for the
   frontend-only phase of the project.

   IMPORTANT RULES
   - Only api.js is allowed to read these constants. Page scripts must NOT.
   - api.js copies this data into localStorage on the very first page load.
   - In Part 3 (Node + Express + MongoDB) this file is no longer needed.

   Field names are camelCase and every record has an "id", so they map
   straight to MongoDB documents later (id -> _id).

   Script order on every page: mockData.js -> api.js -> main.js -> page script
   ============================================================================ */

/* Helper: builds a placeholder photo URL. Same seed always gives the same photo. */
function mockImage(seed) {
  return "https://picsum.photos/seed/shopora-" + seed + "/600/600";
}

/* ---------- Categories ---------- */
const MOCK_CATEGORIES = [
  { id: "c1", name: "Electronics", icon: "🎧", description: "Gadgets and everyday tech" },
  { id: "c2", name: "Fashion", icon: "👕", description: "Clothing and accessories" },
  { id: "c3", name: "Books", icon: "📚", description: "Stories, guides and learning" },
  { id: "c4", name: "Home", icon: "🏠", description: "Comfort for every room" },
  { id: "c5", name: "Sports", icon: "🏋️", description: "Gear to keep you moving" },
  { id: "c6", name: "Beauty", icon: "🧴", description: "Simple self-care essentials" }
];

/* ---------- Users ----------
   DEMO ONLY: passwords are stored as plain text here so the mock login works.
   In the real backend, passwords are hashed (bcrypt) and never returned. */
const MOCK_USERS = [
  {
    id: "u1",
    name: "Aarav Mehta",
    email: "admin@shopora.com",
    password: "Admin@123",
    role: "admin",
    phone: "9876500001",
    address: { street: "12 MG Road", city: "Bengaluru", state: "Karnataka", pincode: "560001" },
    createdAt: "2026-06-01T09:00:00.000Z"
  },
  {
    id: "u2",
    name: "Riya Sharma",
    email: "riya@example.com",
    password: "Riya@1234",
    role: "customer",
    phone: "9876500002",
    address: { street: "221 Lake View Apartments, Indiranagar", city: "Bengaluru", state: "Karnataka", pincode: "560038" },
    createdAt: "2026-07-14T11:30:00.000Z"
  },
  {
    id: "u3",
    name: "Kabir Nair",
    email: "kabir@example.com",
    password: "Kabir@1234",
    role: "customer",
    phone: "9876500003",
    address: { street: "48 Marine Drive", city: "Kochi", state: "Kerala", pincode: "682001" },
    createdAt: "2026-08-02T16:45:00.000Z"
  }
];

/* ---------- Products ----------
   price = original price. discountPrice (optional) = what the customer pays.
   Prices are in Indian Rupees (INR). */
const MOCK_PRODUCTS = [
  /* Electronics */
  {
    id: "p1", name: "Wireless Noise-Cancelling Headphones",
    description: "Over-ear Bluetooth headphones with active noise cancellation, deep bass and up to 30 hours of battery life. Folds flat and comes with a carry case.",
    price: 4999, discountPrice: 3799, category: "Electronics", image: mockImage("headphones"),
    stock: 25, rating: 4.6, reviewsCount: 328, sellerId: "u1", createdAt: "2026-10-18T08:00:00.000Z"
  },
  {
    id: "p2", name: "Smart Fitness Band",
    description: "Track steps, heart rate and sleep with a bright colour display. Water resistant, with a 10-day battery and call and message alerts.",
    price: 2499, discountPrice: 1799, category: "Electronics", image: mockImage("fitness-band"),
    stock: 40, rating: 4.3, reviewsCount: 214, sellerId: "u1", createdAt: "2026-10-12T08:00:00.000Z"
  },
  {
    id: "p3", name: "Portable Bluetooth Speaker",
    description: "A pocket-sized speaker with room-filling sound, a splash-proof body and 12 hours of playtime. Pairs with two phones at once.",
    price: 1999, category: "Electronics", image: mockImage("speaker"),
    stock: 33, rating: 4.4, reviewsCount: 156, sellerId: "u1", createdAt: "2026-09-25T08:00:00.000Z"
  },
  {
    id: "p4", name: "Compact Mechanical Keyboard",
    description: "75% layout keyboard with quiet tactile switches, soft white backlight and a USB-C cable. Works with Windows, macOS and Linux.",
    price: 3499, discountPrice: 2999, category: "Electronics", image: mockImage("keyboard"),
    stock: 18, rating: 4.7, reviewsCount: 92, sellerId: "u1", createdAt: "2026-10-22T08:00:00.000Z"
  },

  /* Fashion */
  {
    id: "p5", name: "Classic Denim Jacket",
    description: "A relaxed-fit denim jacket made from soft washed cotton. Two chest pockets, metal buttons and a timeless cut that goes with everything.",
    price: 2799, discountPrice: 2199, category: "Fashion", image: mockImage("denim-jacket"),
    stock: 4, rating: 4.2, reviewsCount: 78, sellerId: "u1", createdAt: "2026-09-30T08:00:00.000Z"
  },
  {
    id: "p6", name: "Everyday Canvas Sneakers",
    description: "Lightweight canvas sneakers with a cushioned insole and a grippy rubber sole. Easy to clean and comfortable for all-day wear.",
    price: 1799, category: "Fashion", image: mockImage("sneakers"),
    stock: 60, rating: 4.1, reviewsCount: 203, sellerId: "u1", createdAt: "2026-08-28T08:00:00.000Z"
  },
  {
    id: "p7", name: "Minimalist Leather Wallet",
    description: "Slim bifold wallet in genuine leather with six card slots and a coin pocket. Stays thin even when full.",
    price: 899, discountPrice: 699, category: "Fashion", image: mockImage("wallet"),
    stock: 75, rating: 4.5, reviewsCount: 141, sellerId: "u1", createdAt: "2026-10-05T08:00:00.000Z"
  },

  /* Books */
  {
    id: "p8", name: "The Pocket Productivity Handbook",
    description: "A short, practical guide to planning your day, beating procrastination and building habits that last. Easy to read in a weekend.",
    price: 399, category: "Books", image: mockImage("handbook"),
    stock: 120, rating: 4.0, reviewsCount: 64, sellerId: "u1", createdAt: "2026-08-15T08:00:00.000Z"
  },
  {
    id: "p9", name: "Stories from the Silk Route",
    description: "A collection of travel tales and folk stories from the old trade routes of Asia, beautifully illustrated across 240 pages.",
    price: 549, discountPrice: 449, category: "Books", image: mockImage("silk-route"),
    stock: 52, rating: 4.8, reviewsCount: 187, sellerId: "u1", createdAt: "2026-09-10T08:00:00.000Z"
  },
  {
    id: "p10", name: "Beginner's Guide to Balcony Gardening",
    description: "Learn to grow herbs, vegetables and flowers in small spaces. Includes a seasonal planting calendar and simple pot-and-soil tips.",
    price: 349, category: "Books", image: mockImage("gardening-book"),
    stock: 85, rating: 4.3, reviewsCount: 49, sellerId: "u1", createdAt: "2026-07-30T08:00:00.000Z"
  },

  /* Home */
  {
    id: "p11", name: "Ceramic Coffee Mug Set of 4",
    description: "Four hand-glazed ceramic mugs, each holding 300 ml. Dishwasher and microwave safe, in calm earthy tones.",
    price: 799, discountPrice: 649, category: "Home", image: mockImage("mug-set"),
    stock: 44, rating: 4.4, reviewsCount: 112, sellerId: "u1", createdAt: "2026-09-18T08:00:00.000Z"
  },
  {
    id: "p12", name: "Linen Throw Blanket",
    description: "A breathable, stone-washed linen blanket for sofas and beds. Gets softer with every wash. Size 130 x 180 cm.",
    price: 1599, category: "Home", image: mockImage("blanket"),
    stock: 29, rating: 4.6, reviewsCount: 71, sellerId: "u1", createdAt: "2026-10-08T08:00:00.000Z"
  },
  {
    id: "p13", name: "Aroma Soy Candle Trio",
    description: "Three hand-poured soy candles in lavender, vanilla and sandalwood. Burns cleanly for about 25 hours each.",
    price: 699, discountPrice: 549, category: "Home", image: mockImage("candles"),
    stock: 58, rating: 4.5, reviewsCount: 95, sellerId: "u1", createdAt: "2026-10-20T08:00:00.000Z"
  },
  {
    id: "p14", name: "Bamboo Desk Organiser",
    description: "A tidy desk organiser with compartments for pens, notes, a phone and cables. Made from sustainably sourced bamboo.",
    price: 999, category: "Home", image: mockImage("desk-organiser"),
    stock: 0, rating: 4.2, reviewsCount: 38, sellerId: "u1", createdAt: "2026-08-05T08:00:00.000Z"
  },

  /* Sports */
  {
    id: "p15", name: "Anti-Slip Yoga Mat",
    description: "Extra-thick 6 mm mat with a textured non-slip surface and alignment lines. Comes with a carry strap.",
    price: 1299, discountPrice: 999, category: "Sports", image: mockImage("yoga-mat"),
    stock: 36, rating: 4.4, reviewsCount: 167, sellerId: "u1", createdAt: "2026-09-02T08:00:00.000Z"
  },
  {
    id: "p16", name: "Adjustable Dumbbell Pair",
    description: "A pair of dumbbells that adjust from 2 kg to 12 kg each. Quick-lock dials, anti-roll design and a compact storage tray.",
    price: 2999, category: "Sports", image: mockImage("dumbbells"),
    stock: 14, rating: 4.7, reviewsCount: 83, sellerId: "u1", createdAt: "2026-10-14T08:00:00.000Z"
  },
  {
    id: "p17", name: "Insulated Steel Water Bottle",
    description: "750 ml double-wall bottle that keeps drinks cold for 24 hours or hot for 12. Leak-proof lid and a powder-coated finish.",
    price: 649, discountPrice: 499, category: "Sports", image: mockImage("bottle"),
    stock: 90, rating: 4.6, reviewsCount: 259, sellerId: "u1", createdAt: "2026-08-20T08:00:00.000Z"
  },

  /* Beauty */
  {
    id: "p18", name: "Vitamin C Face Serum",
    description: "A lightweight 10% vitamin C serum with hyaluronic acid for a brighter, even-looking skin tone. 30 ml, suitable for daily use.",
    price: 899, discountPrice: 699, category: "Beauty", image: mockImage("serum"),
    stock: 47, rating: 4.3, reviewsCount: 176, sellerId: "u1", createdAt: "2026-10-25T08:00:00.000Z"
  },
  {
    id: "p19", name: "Herbal Hair Oil",
    description: "A blend of coconut, amla and hibiscus oils for nourished, shiny hair. Light on the scalp and free from mineral oil. 200 ml.",
    price: 449, category: "Beauty", image: mockImage("hair-oil"),
    stock: 66, rating: 4.1, reviewsCount: 121, sellerId: "u1", createdAt: "2026-07-22T08:00:00.000Z"
  }
];

/* ---------- Orders (3 sample orders for customer Riya Sharma, u2) ----------
   Totals follow the same rules as api.js:
   delivery = 0 if subtotal >= 999, otherwise 49. Tax = 5% of subtotal, rounded. */
const MOCK_ORDERS = [
  {
    id: "ORD-1001",
    userId: "u2",
    items: [
      { productId: "p1", name: "Wireless Noise-Cancelling Headphones", image: mockImage("headphones"), price: 3799, quantity: 1 },
      { productId: "p9", name: "Stories from the Silk Route", image: mockImage("silk-route"), price: 449, quantity: 2 }
    ],
    subtotal: 4697,
    deliveryFee: 0,
    tax: 235,
    total: 4932,
    status: "Delivered",
    paymentMethod: "cod",
    shippingAddress: {
      fullName: "Riya Sharma", phone: "9876500002",
      street: "221 Lake View Apartments, Indiranagar", city: "Bengaluru", state: "Karnataka", pincode: "560038"
    },
    createdAt: "2026-09-12T10:15:00.000Z"
  },
  {
    id: "ORD-1002",
    userId: "u2",
    items: [
      { productId: "p15", name: "Anti-Slip Yoga Mat", image: mockImage("yoga-mat"), price: 999, quantity: 1 },
      { productId: "p17", name: "Insulated Steel Water Bottle", image: mockImage("bottle"), price: 499, quantity: 1 }
    ],
    subtotal: 1498,
    deliveryFee: 0,
    tax: 75,
    total: 1573,
    status: "Shipped",
    paymentMethod: "card-upi-demo",
    shippingAddress: {
      fullName: "Riya Sharma", phone: "9876500002",
      street: "221 Lake View Apartments, Indiranagar", city: "Bengaluru", state: "Karnataka", pincode: "560038"
    },
    createdAt: "2026-10-21T14:40:00.000Z"
  },
  {
    id: "ORD-1003",
    userId: "u2",
    items: [
      { productId: "p8", name: "The Pocket Productivity Handbook", image: mockImage("handbook"), price: 399, quantity: 1 },
      { productId: "p10", name: "Beginner's Guide to Balcony Gardening", image: mockImage("gardening-book"), price: 349, quantity: 1 }
    ],
    subtotal: 748,
    deliveryFee: 49,
    tax: 37,
    total: 834,
    status: "Pending",
    paymentMethod: "cod",
    shippingAddress: {
      fullName: "Riya Sharma", phone: "9876500002",
      street: "221 Lake View Apartments, Indiranagar", city: "Bengaluru", state: "Karnataka", pincode: "560038"
    },
    createdAt: "2026-10-26T18:05:00.000Z"
  }
];
