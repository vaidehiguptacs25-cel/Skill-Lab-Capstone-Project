/* ============================================================================
   api.js
   Purpose: THE ONLY FILE THAT TOUCHES APPLICATION DATA.

   - Every page script calls the functions in this file. No other file may read
     mockData.js or localStorage for products, users, carts or orders.
   - Every function is async and returns a Promise that resolves to
       { success: true,  data: ..., message: "" }     or
       { success: false, message: "What went wrong" }
     This is the same shape the real REST API will return in Part 3.
   - USE_MOCK = true  -> data lives in localStorage (seeded from mockData.js).
     USE_MOCK = false -> each function calls the real backend at BASE_URL.
     In Part 3 only this file needs to change.

   Script order on every page: mockData.js -> api.js -> main.js -> page script
   ============================================================================ */

const USE_MOCK = true;
const BASE_URL = "http://localhost:5000/api"; // placeholder: backend arrives in Part 3
const ORDER_STATUSES = ["Pending", "Shipped", "Delivered", "Cancelled"];

(function () {
  "use strict";

  /* ------------------------------------------------------------------------
     1. SETTINGS
     ------------------------------------------------------------------------ */
  const DEFAULT_DELAY_MS = 300;  // fake network delay for most calls
  const QUICK_DELAY_MS = 120;    // cart and session checks feel instant in real apps
  const DEFAULT_PAGE_SIZE = 8;

  // Pricing rules (the backend will own these in Part 3)
  const FREE_DELIVERY_THRESHOLD = 999; // free delivery at or above this subtotal
  const DELIVERY_FEE = 49;
  const TAX_RATE = 0.05;

  const PAYMENT_METHODS = ["cod", "card-upi-demo"];

  // localStorage keys
  const STORAGE_KEYS = {
    seeded: "ec_seeded",
    users: "ec_users",
    products: "ec_products",
    categories: "ec_categories",
    cart: "ec_cart",
    orders: "ec_orders",
    session: "ec_session"
  };

  /* ------------------------------------------------------------------------
     2. SMALL HELPERS (private to this file)
     ------------------------------------------------------------------------ */

  // Pause for a moment to imitate a network request.
  function wait(ms = DEFAULT_DELAY_MS) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // Build a success response.
  function ok(data, message = "") {
    return { success: true, data: data, message: message };
  }

  // Build an error response.
  function fail(message) {
    return { success: false, message: message };
  }

  // Make an independent copy of plain data so callers cannot change storage by accident.
  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  // Remove one localStorage key without crashing if storage is unavailable.
  function removeKey(key) {
    try {
      localStorage.removeItem(key);
    } catch (error) {
      // Storage not available (e.g. private mode): nothing to remove.
    }
  }

  // Read JSON from localStorage. Missing or corrupted data returns null (and corrupted data is deleted).
  function readJson(key) {
    try {
      const raw = localStorage.getItem(key);
      return raw === null ? null : JSON.parse(raw);
    } catch (error) {
      removeKey(key);
      return null;
    }
  }

  // Write JSON to localStorage. Returns false if the browser refuses (e.g. storage full).
  function writeJson(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (error) {
      return false;
    }
  }

  // Read a list from storage; if it is missing or corrupted, reset it from the seed data.
  function loadCollection(key, seedData) {
    const stored = readJson(key);
    if (Array.isArray(stored)) {
      return stored;
    }
    const fresh = clone(seedData);
    writeJson(key, fresh);
    return fresh;
  }

  function loadUsers() { return loadCollection(STORAGE_KEYS.users, MOCK_USERS); }
  function loadProducts() { return loadCollection(STORAGE_KEYS.products, MOCK_PRODUCTS); }
  function loadCategories() { return loadCollection(STORAGE_KEYS.categories, MOCK_CATEGORIES); }
  function loadOrders() { return loadCollection(STORAGE_KEYS.orders, MOCK_ORDERS); }
  function loadCart() { return loadCollection(STORAGE_KEYS.cart, []); }

  // Copy mock data into localStorage the very first time the site is opened.
  function seedMockDataOnce() {
    if (!USE_MOCK || readJson(STORAGE_KEYS.seeded) === true) {
      return;
    }
    writeJson(STORAGE_KEYS.users, clone(MOCK_USERS));
    writeJson(STORAGE_KEYS.products, clone(MOCK_PRODUCTS));
    writeJson(STORAGE_KEYS.categories, clone(MOCK_CATEGORIES));
    writeJson(STORAGE_KEYS.orders, clone(MOCK_ORDERS));
    writeJson(STORAGE_KEYS.cart, []);
    writeJson(STORAGE_KEYS.seeded, true);
  }

  // Create a simple unique id such as "p_k3j9x2ab".
  function generateId(prefix) {
    return prefix + "_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  }

  // Send a request to the real backend (only used when USE_MOCK is false).
  async function request(method, path, body) {
    try {
      const session = readJson(STORAGE_KEYS.session);
      const headers = { "Content-Type": "application/json" };
      if (session && session.token) {
        headers.Authorization = "Bearer " + session.token;
      }
      const response = await fetch(BASE_URL + path, {
        method: method,
        headers: headers,
        body: body === undefined ? undefined : JSON.stringify(body)
      });
      // The backend must reply with { success, data } or { success: false, message }.
      return await response.json();
    } catch (error) {
      return fail("Cannot reach the server. Please check your connection and try again.");
    }
  }

  // Turn { a: 1, b: "" } into "?a=1" (empty values are skipped).
  function toQueryString(params) {
    const query = new URLSearchParams();
    Object.keys(params).forEach((key) => {
      const value = params[key];
      if (value !== undefined && value !== null && value !== "") {
        query.set(key, value);
      }
    });
    const text = query.toString();
    return text ? "?" + text : "";
  }

  // Convert a value to a number, or null if it is empty / not a number.
  function toNumberOrNull(value) {
    if (value === undefined || value === null || value === "") {
      return null;
    }
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
  }

  /* ------------------------------------------------------------------------
     3. VALIDATION (the backend will repeat these checks; never trust the browser alone)
     ------------------------------------------------------------------------ */
  function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(email || "").trim());
  }

  function isValidPhone(phone) {
    return /^\d{10}$/.test(String(phone || "").trim());
  }

  function isValidPincode(pincode) {
    return /^\d{6}$/.test(String(pincode || "").trim());
  }

  function isValidPassword(password) {
    const text = String(password || "");
    return text.length >= 8 && /[A-Za-z]/.test(text) && /\d/.test(text);
  }

  // Check shipping details. Returns an error message, or "" when everything is fine.
  function validateShipping(shipping) {
    const data = shipping || {};
    if (!String(data.fullName || "").trim()) return "Please enter the full name for delivery.";
    if (!isValidPhone(data.phone)) return "Phone number must be exactly 10 digits.";
    if (!String(data.street || "").trim()) return "Please enter the delivery address.";
    if (!String(data.city || "").trim()) return "Please enter the city.";
    if (!String(data.state || "").trim()) return "Please enter the state.";
    if (!isValidPincode(data.pincode)) return "Pincode must be exactly 6 digits.";
    return "";
  }

  // Check product details. Returns an error message, or "" when everything is fine.
  function validateProduct(data) {
    if (!String(data.name || "").trim()) return "Product name is required.";
    if (!String(data.description || "").trim()) return "Product description is required.";
    const price = Number(data.price);
    if (!Number.isFinite(price) || price <= 0) return "Price must be greater than 0.";
    if (data.discountPrice !== undefined && data.discountPrice !== null && data.discountPrice !== "") {
      const discountPrice = Number(data.discountPrice);
      if (!Number.isFinite(discountPrice) || discountPrice <= 0 || discountPrice >= price) {
        return "Discount price must be greater than 0 and lower than the price.";
      }
    }
    const stock = Number(data.stock);
    if (!Number.isInteger(stock) || stock < 0) return "Stock must be a whole number, 0 or more.";
    const categoryExists = loadCategories().some((category) => category.name === data.category);
    if (!categoryExists) return "Please choose a valid category.";
    return "";
  }

  /* ------------------------------------------------------------------------
     4. PRODUCT AND USER SHAPING
     ------------------------------------------------------------------------ */

  // Price the customer actually pays.
  function getFinalPrice(product) {
    const hasDiscount = Number(product.discountPrice) > 0 && Number(product.discountPrice) < Number(product.price);
    return hasDiscount ? Number(product.discountPrice) : Number(product.price);
  }

  // Add computed fields (finalPrice, discountPercent) so the UI never has to calculate them.
  function presentProduct(product) {
    const finalPrice = getFinalPrice(product);
    const discountPercent = finalPrice < product.price
      ? Math.round(((product.price - finalPrice) / product.price) * 100)
      : 0;
    return Object.assign({}, product, { finalPrice: finalPrice, discountPercent: discountPercent });
  }

  // Copy of a user without the password field.
  function stripPassword(user) {
    const safeUser = Object.assign({}, user);
    delete safeUser.password;
    return safeUser;
  }

  // Find the logged-in user from the session, or null if nobody is logged in.
  function getSessionUser() {
    const session = readJson(STORAGE_KEYS.session);
    if (!session || !session.userId) {
      return null;
    }
    const user = loadUsers().find((item) => item.id === session.userId);
    if (!user) {
      removeKey(STORAGE_KEYS.session); // user no longer exists: log out safely
      return null;
    }
    return stripPassword(user);
  }

  // True when the user's role is one of the given roles.
  function hasRole(user, roles) {
    return Boolean(user) && roles.indexOf(user.role) !== -1;
  }

  /* ------------------------------------------------------------------------
     5. CART HELPERS
     ------------------------------------------------------------------------ */

  // Work out subtotal, delivery, tax and total for a list of cart items.
  function buildCartSummary(items) {
    const subtotal = items.reduce((sum, item) => sum + item.lineTotal, 0);
    const deliveryFee = subtotal === 0 || subtotal >= FREE_DELIVERY_THRESHOLD ? 0 : DELIVERY_FEE;
    const tax = Math.round(subtotal * TAX_RATE);
    return {
      itemCount: items.reduce((sum, item) => sum + item.quantity, 0),
      subtotal: subtotal,
      deliveryFee: deliveryFee,
      tax: tax,
      total: subtotal + deliveryFee + tax,
      freeDeliveryThreshold: FREE_DELIVERY_THRESHOLD
    };
  }

  // Combine stored cart lines with live product details. Removes lines for deleted or sold-out products.
  function buildCart() {
    const storedCart = loadCart();
    const products = loadProducts();
    const items = [];

    storedCart.forEach((line) => {
      const product = products.find((item) => item.id === line.productId);
      if (!product || product.stock < 1) {
        return; // product deleted or sold out: drop the line
      }
      const quantity = Math.min(line.quantity, product.stock); // never more than stock
      const shaped = presentProduct(product);
      items.push({
        productId: product.id,
        quantity: quantity,
        unitPrice: shaped.finalPrice,
        lineTotal: shaped.finalPrice * quantity,
        product: shaped
      });
    });

    // Save the cleaned cart if some lines were dropped or reduced.
    const cleanedCart = items.map((item) => ({ productId: item.productId, quantity: item.quantity }));
    if (JSON.stringify(cleanedCart) !== JSON.stringify(storedCart)) {
      writeJson(STORAGE_KEYS.cart, cleanedCart);
    }

    return { items: items, summary: buildCartSummary(items) };
  }

  /* ========================================================================
     6. AUTH
     ======================================================================== */

  // Future: POST /api/auth/register
  async function registerUser(data) {
    if (!USE_MOCK) return request("POST", "/auth/register", data);
    await wait();

    const input = data || {};
    const name = String(input.name || "").trim();
    const email = String(input.email || "").trim().toLowerCase();
    const role = input.role === "seller" ? "seller" : "customer"; // nobody can self-register as admin

    if (!name) return fail("Please enter your name.");
    if (!isValidEmail(email)) return fail("Please enter a valid email address.");
    if (!isValidPhone(input.phone)) return fail("Phone number must be exactly 10 digits.");
    if (!isValidPassword(input.password)) {
      return fail("Password must be at least 8 characters and include a letter and a number.");
    }

    const users = loadUsers();
    if (users.some((user) => user.email === email)) {
      return fail("An account with this email already exists. Try logging in.");
    }

    // DEMO ONLY: the password is stored as plain text. The real backend will hash it (bcrypt).
    const newUser = {
      id: generateId("u"),
      name: name,
      email: email,
      password: input.password,
      role: role,
      phone: String(input.phone).trim(),
      address: { street: "", city: "", state: "", pincode: "" },
      createdAt: new Date().toISOString()
    };
    users.push(newUser);
    writeJson(STORAGE_KEYS.users, users);
    return ok(stripPassword(newUser), "Account created. You can log in now.");
  }

  // Future: POST /api/auth/login
  async function loginUser(email, password) {
    if (!USE_MOCK) {
      const response = await request("POST", "/auth/login", { email: email, password: password });
      if (response.success && response.data) {
        // Expected: data = { user, token }. Keep the token for later requests.
        writeJson(STORAGE_KEYS.session, { token: response.data.token, userId: response.data.user.id });
      }
      return response;
    }
    await wait();

    const cleanEmail = String(email || "").trim().toLowerCase();
    if (!cleanEmail || !password) return fail("Please enter your email and password.");

    const user = loadUsers().find((item) => item.email === cleanEmail && item.password === password);
    if (!user) return fail("Incorrect email or password.");

    // Fake token. In Part 3 the server returns a real JWT.
    const token = "mock-token-" + user.id + "-" + Date.now();
    writeJson(STORAGE_KEYS.session, { token: token, userId: user.id });
    return ok({ user: stripPassword(user), token: token }, "Welcome back, " + user.name.split(" ")[0] + "!");
  }

  // Future: POST /api/auth/logout (or simply delete the JWT on the client)
  async function logoutUser() {
    if (USE_MOCK) {
      await wait(QUICK_DELAY_MS);
    }
    removeKey(STORAGE_KEYS.session);
    return ok(null, "You have been logged out.");
  }

  // Future: GET /api/auth/me
  async function getCurrentUser() {
    if (!USE_MOCK) return request("GET", "/auth/me");
    await wait(QUICK_DELAY_MS);
    const user = getSessionUser();
    return user ? ok(user) : fail("You are not logged in.");
  }

  // Future: PUT /api/users/profile
  async function updateProfile(data) {
    if (!USE_MOCK) return request("PUT", "/users/profile", data);
    await wait();

    const sessionUser = getSessionUser();
    if (!sessionUser) return fail("Please log in to update your profile.");

    const input = data || {};
    const address = input.address || {};
    if (!String(input.name || "").trim()) return fail("Name cannot be empty.");
    if (!isValidPhone(input.phone)) return fail("Phone number must be exactly 10 digits.");
    if (address.pincode && !isValidPincode(address.pincode)) return fail("Pincode must be exactly 6 digits.");

    const users = loadUsers();
    const user = users.find((item) => item.id === sessionUser.id);
    user.name = String(input.name).trim();
    user.phone = String(input.phone).trim();
    user.address = {
      street: String(address.street || "").trim(),
      city: String(address.city || "").trim(),
      state: String(address.state || "").trim(),
      pincode: String(address.pincode || "").trim()
    };
    writeJson(STORAGE_KEYS.users, users);
    return ok(stripPassword(user), "Profile updated.");
  }

  /* ========================================================================
     7. CATEGORIES
     ======================================================================== */

  // Future: GET /api/categories
  async function getCategories() {
    if (!USE_MOCK) return request("GET", "/categories");
    await wait();
    const products = loadProducts();
    const categories = loadCategories().map((category) => {
      const productCount = products.filter((product) => product.category === category.name).length;
      return Object.assign({}, category, { productCount: productCount });
    });
    return ok(categories);
  }

  /* ========================================================================
     8. PRODUCTS
     ======================================================================== */

  // Future: GET /api/products?search=&category=&minPrice=&maxPrice=&sort=&page=&limit=
  // sort can be: "price-asc", "price-desc", "rating", "newest"
  // Returns { products, total, page, totalPages, limit }
  async function getProducts(options = {}) {
    if (!USE_MOCK) return request("GET", "/products" + toQueryString(options));
    await wait();

    const search = String(options.search || "").trim().toLowerCase();
    const category = String(options.category || "").trim().toLowerCase();
    const minPrice = toNumberOrNull(options.minPrice);
    const maxPrice = toNumberOrNull(options.maxPrice);
    const sellerId = String(options.sellerId || "");
    const limit = Math.max(1, Number(options.limit) || DEFAULT_PAGE_SIZE);

    let list = loadProducts().map(presentProduct);

    if (search) {
      list = list.filter((product) =>
        (product.name + " " + product.description + " " + product.category).toLowerCase().includes(search)
      );
    }
    if (category && category !== "all") {
      list = list.filter((product) => product.category.toLowerCase() === category);
    }
    if (minPrice !== null) {
      list = list.filter((product) => product.finalPrice >= minPrice);
    }
    if (maxPrice !== null) {
      list = list.filter((product) => product.finalPrice <= maxPrice);
    }
    if (sellerId) {
      list = list.filter((product) => product.sellerId === sellerId);
    }

    switch (options.sort) {
      case "price-asc":
        list.sort((a, b) => a.finalPrice - b.finalPrice);
        break;
      case "price-desc":
        list.sort((a, b) => b.finalPrice - a.finalPrice);
        break;
      case "rating":
        list.sort((a, b) => b.rating - a.rating || b.reviewsCount - a.reviewsCount);
        break;
      case "newest":
        list.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        break;
      default:
        break; // keep stored order
    }

    const total = list.length;
    const totalPages = Math.max(1, Math.ceil(total / limit));
    const page = Math.min(Math.max(1, parseInt(options.page, 10) || 1), totalPages);
    const start = (page - 1) * limit;

    return ok({
      products: list.slice(start, start + limit),
      total: total,
      page: page,
      totalPages: totalPages,
      limit: limit
    });
  }

  // Future: GET /api/products/:id
  async function getProductById(id) {
    if (!USE_MOCK) return request("GET", "/products/" + encodeURIComponent(id));
    await wait();
    const product = loadProducts().find((item) => item.id === id);
    return product ? ok(presentProduct(product)) : fail("We could not find that product.");
  }

  // Future: POST /api/products   (seller/admin only)
  async function createProduct(data) {
    if (!USE_MOCK) return request("POST", "/products", data);
    await wait();

    const user = getSessionUser();
    if (!hasRole(user, ["admin", "seller"])) return fail("Only sellers and admins can add products.");

    const input = data || {};
    const message = validateProduct(input);
    if (message) return fail(message);

    const name = String(input.name).trim();
    const hasDiscount = input.discountPrice !== undefined && input.discountPrice !== null && input.discountPrice !== "";
    const newProduct = {
      id: generateId("p"),
      name: name,
      description: String(input.description).trim(),
      price: Number(input.price),
      category: input.category,
      image: String(input.image || "").trim() || "https://picsum.photos/seed/" + encodeURIComponent(name) + "/600/600",
      stock: Number(input.stock),
      rating: 0,
      reviewsCount: 0,
      sellerId: user.id,
      createdAt: new Date().toISOString()
    };
    if (hasDiscount) {
      newProduct.discountPrice = Number(input.discountPrice);
    }

    const products = loadProducts();
    products.push(newProduct);
    writeJson(STORAGE_KEYS.products, products);
    return ok(presentProduct(newProduct), "Product added.");
  }

  // Future: PUT /api/products/:id   (owner seller or admin only)
  async function updateProduct(id, data) {
    if (!USE_MOCK) return request("PUT", "/products/" + encodeURIComponent(id), data);
    await wait();

    const user = getSessionUser();
    if (!hasRole(user, ["admin", "seller"])) return fail("Only sellers and admins can edit products.");

    const products = loadProducts();
    const product = products.find((item) => item.id === id);
    if (!product) return fail("We could not find that product.");
    if (user.role === "seller" && product.sellerId !== user.id) return fail("You can only edit your own products.");

    // Merge the changes, then validate the complete product.
    const merged = Object.assign({}, product, data || {});
    const message = validateProduct(merged);
    if (message) return fail(message);

    product.name = String(merged.name).trim();
    product.description = String(merged.description).trim();
    product.price = Number(merged.price);
    product.category = merged.category;
    product.stock = Number(merged.stock);
    if (String(merged.image || "").trim()) {
      product.image = String(merged.image).trim();
    }
    const hasDiscount = merged.discountPrice !== undefined && merged.discountPrice !== null && merged.discountPrice !== "";
    if (hasDiscount) {
      product.discountPrice = Number(merged.discountPrice);
    } else {
      delete product.discountPrice;
    }

    writeJson(STORAGE_KEYS.products, products);
    return ok(presentProduct(product), "Product updated.");
  }

  // Future: DELETE /api/products/:id   (owner seller or admin only)
  async function deleteProduct(id) {
    if (!USE_MOCK) return request("DELETE", "/products/" + encodeURIComponent(id));
    await wait();

    const user = getSessionUser();
    if (!hasRole(user, ["admin", "seller"])) return fail("Only sellers and admins can delete products.");

    const products = loadProducts();
    const index = products.findIndex((item) => item.id === id);
    if (index === -1) return fail("We could not find that product.");
    if (user.role === "seller" && products[index].sellerId !== user.id) {
      return fail("You can only delete your own products.");
    }

    products.splice(index, 1);
    writeJson(STORAGE_KEYS.products, products);
    return ok(null, "Product deleted.");
  }

  /* ========================================================================
     9. CART
     Every cart function returns { items, summary } so the UI can redraw at once.
     ======================================================================== */

  // Future: GET /api/cart
  async function getCart() {
    if (!USE_MOCK) return request("GET", "/cart");
    await wait(QUICK_DELAY_MS);
    return ok(buildCart());
  }

  // Future: POST /api/cart   body: { productId, quantity }
  async function addToCart(productId, qty = 1) {
    if (!USE_MOCK) return request("POST", "/cart", { productId: productId, quantity: qty });
    await wait(QUICK_DELAY_MS);

    const quantity = Number(qty);
    if (!Number.isInteger(quantity) || quantity < 1) return fail("Quantity must be a whole number of 1 or more.");

    const product = loadProducts().find((item) => item.id === productId);
    if (!product) return fail("This product is no longer available.");
    if (product.stock < 1) return fail("Sorry, this product is out of stock.");

    const cart = loadCart();
    const line = cart.find((item) => item.productId === productId);
    const newQuantity = (line ? line.quantity : 0) + quantity;
    if (newQuantity > product.stock) {
      return fail("Only " + product.stock + " unit(s) are in stock. You already have " + (line ? line.quantity : 0) + " in your cart.");
    }

    if (line) {
      line.quantity = newQuantity;
    } else {
      cart.push({ productId: productId, quantity: quantity });
    }
    writeJson(STORAGE_KEYS.cart, cart);
    return ok(buildCart(), "Added to your cart.");
  }

  // Future: PUT /api/cart/:productId   body: { quantity }
  async function updateCartItem(productId, qty) {
    if (!USE_MOCK) return request("PUT", "/cart/" + encodeURIComponent(productId), { quantity: qty });
    await wait(QUICK_DELAY_MS);

    const quantity = Number(qty);
    if (!Number.isInteger(quantity) || quantity < 1) return fail("Quantity must be a whole number of 1 or more.");

    const product = loadProducts().find((item) => item.id === productId);
    if (!product) return fail("This product is no longer available.");
    if (quantity > product.stock) return fail("Only " + product.stock + " unit(s) are in stock.");

    const cart = loadCart();
    const line = cart.find((item) => item.productId === productId);
    if (!line) return fail("This item is not in your cart.");

    line.quantity = quantity;
    writeJson(STORAGE_KEYS.cart, cart);
    return ok(buildCart());
  }

  // Future: DELETE /api/cart/:productId
  async function removeFromCart(productId) {
    if (!USE_MOCK) return request("DELETE", "/cart/" + encodeURIComponent(productId));
    await wait(QUICK_DELAY_MS);
    const cart = loadCart().filter((item) => item.productId !== productId);
    writeJson(STORAGE_KEYS.cart, cart);
    return ok(buildCart(), "Item removed.");
  }

  // Future: DELETE /api/cart
  async function clearCart() {
    if (!USE_MOCK) return request("DELETE", "/cart");
    await wait(QUICK_DELAY_MS);
    writeJson(STORAGE_KEYS.cart, []);
    return ok(buildCart());
  }

  /* ========================================================================
     10. ORDERS
     ======================================================================== */

  // Future: POST /api/orders   body: { shippingAddress, paymentMethod }
  // The order is created from the logged-in user's current cart.
  async function placeOrder(orderData) {
    if (!USE_MOCK) return request("POST", "/orders", orderData);
    await wait();

    const user = getSessionUser();
    if (!user) return fail("Please log in to place an order.");

    const input = orderData || {};
    const shippingMessage = validateShipping(input.shippingAddress);
    if (shippingMessage) return fail(shippingMessage);
    if (PAYMENT_METHODS.indexOf(input.paymentMethod) === -1) return fail("Please choose a payment method.");

    const cart = buildCart();
    if (cart.items.length === 0) return fail("Your cart is empty.");

    // Re-check stock, then reduce it.
    const products = loadProducts();
    for (const item of cart.items) {
      const product = products.find((entry) => entry.id === item.productId);
      if (!product || product.stock < item.quantity) {
        return fail(item.product.name + " does not have enough stock. Please update your cart.");
      }
    }
    cart.items.forEach((item) => {
      products.find((entry) => entry.id === item.productId).stock -= item.quantity;
    });
    writeJson(STORAGE_KEYS.products, products);

    // Order ids look like ORD-1004: one more than the highest existing number.
    const orders = loadOrders();
    const highest = orders.reduce((max, order) => Math.max(max, parseInt(String(order.id).replace("ORD-", ""), 10) || 0), 1000);
    const shipping = input.shippingAddress;

    const newOrder = {
      id: "ORD-" + (highest + 1),
      userId: user.id,
      items: cart.items.map((item) => ({
        productId: item.productId,
        name: item.product.name,
        image: item.product.image,
        price: item.unitPrice,
        quantity: item.quantity
      })),
      subtotal: cart.summary.subtotal,
      deliveryFee: cart.summary.deliveryFee,
      tax: cart.summary.tax,
      total: cart.summary.total,
      status: "Pending",
      paymentMethod: input.paymentMethod,
      shippingAddress: {
        fullName: String(shipping.fullName).trim(),
        phone: String(shipping.phone).trim(),
        street: String(shipping.street).trim(),
        city: String(shipping.city).trim(),
        state: String(shipping.state).trim(),
        pincode: String(shipping.pincode).trim()
      },
      createdAt: new Date().toISOString()
    };

    orders.push(newOrder);
    writeJson(STORAGE_KEYS.orders, orders);
    writeJson(STORAGE_KEYS.cart, []); // the cart is emptied after a successful order
    return ok(newOrder, "Order placed successfully!");
  }

  // Future: GET /api/orders/my
  async function getMyOrders() {
    if (!USE_MOCK) return request("GET", "/orders/my");
    await wait();
    const user = getSessionUser();
    if (!user) return fail("Please log in to see your orders.");
    const orders = loadOrders()
      .filter((order) => order.userId === user.id)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    return ok(orders);
  }

  // Future: GET /api/orders   (admin/seller only)
  async function getAllOrders() {
    if (!USE_MOCK) return request("GET", "/orders");
    await wait();
    const user = getSessionUser();
    if (!hasRole(user, ["admin", "seller"])) return fail("Only sellers and admins can see all orders.");
    const orders = loadOrders().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    return ok(orders);
  }

  // Future: PUT /api/orders/:id/status   body: { status }   (admin/seller only)
  async function updateOrderStatus(orderId, status) {
    if (!USE_MOCK) return request("PUT", "/orders/" + encodeURIComponent(orderId) + "/status", { status: status });
    await wait();

    const user = getSessionUser();
    if (!hasRole(user, ["admin", "seller"])) return fail("Only sellers and admins can update orders.");
    if (ORDER_STATUSES.indexOf(status) === -1) return fail("That is not a valid order status.");

    const orders = loadOrders();
    const order = orders.find((item) => item.id === orderId);
    if (!order) return fail("We could not find that order.");

    // Cancelling an order puts its items back in stock.
    if (status === "Cancelled" && order.status !== "Cancelled") {
      const products = loadProducts();
      order.items.forEach((item) => {
        const product = products.find((entry) => entry.id === item.productId);
        if (product) {
          product.stock += item.quantity;
        }
      });
      writeJson(STORAGE_KEYS.products, products);
    }

    order.status = status;
    writeJson(STORAGE_KEYS.orders, orders);
    return ok(order, "Order status updated.");
  }

  /* ------------------------------------------------------------------------
     11. START UP + PUBLIC API
     Only the functions below are visible to other scripts.
     ------------------------------------------------------------------------ */
  seedMockDataOnce();

  Object.assign(window, {
    registerUser, loginUser, logoutUser, getCurrentUser, updateProfile,
    getCategories,
    getProducts, getProductById, createProduct, updateProduct, deleteProduct,
    getCart, addToCart, updateCartItem, removeFromCart, clearCart,
    placeOrder, getMyOrders, getAllOrders, updateOrderStatus
  });
})();
